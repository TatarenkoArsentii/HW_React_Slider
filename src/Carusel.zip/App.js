import React from "react";
import "./App.css";
import Carusel from "./components/Carusel";
import UserList from "./components/user_list";
// import Carusel from "./components/Carusel";
// const slides = [
//   "http://fotorelax.ru/wp-content/uploads/2016/03/Beautiful-photos-and-pictures-on-various-subjects-01.jpg",
//   "https://st2.depositphotos.com/1064024/10769/i/600/depositphotos_107694484-stock-photo-little-boy.jpg",
// ];

const slides = [
  {
    src: "http://fotorelax.ru/wp-content/uploads/2016/03/Beautiful-photos-and-pictures-on-various-subjects-01.jpg",
    title: "Some Image",
  },
  {
    src: "https://st2.depositphotos.com/1064024/10769/i/600/depositphotos_107694484-stock-photo-little-boy.jpg",
    title: "Some Image",
  },
];

function App() {
  return <Carusel slides={slides} />;
}

export default App;
